# Khaosan Tapas Bar — Google Business Profile Toolkit

---

## 1. BUSINESS DESCRIPTION (copy-paste into GBP)

> Character limit: 750. This is 698 characters — paste exactly as-is.

```
Modern Thai tapas and clarified cocktails in a heritage shophouse on Lebuh Campbell, George Town. Helmed by Chef Pond and Chef Toei — MasterChef Thailand Season 3 finalists — Khaosan brings Bangkok street food to the bar: betel leaf parcels, Kuagling Tacos, chargrilled meats, and signature ferment-forward small plates.

Choose from à la carte, or let the kitchen take you through our 7-course Light Tasting (RM 128) or 9-course Khaosan Tasting (RM 158). Our cocktail programme runs from Thai-ingredient clarified cocktails to classics done right.

Reservations via WhatsApp. Walk-ins welcome at the bar.

Open Tuesday – Sunday, 6pm – midnight. Monday closed.
56 Lebuh Campbell, George Town, Penang.
```

---

## 2. CATEGORIES TO SET IN GBP

**Primary category:** Tapas bar ✅ (already set)

**Add these secondary categories:**
- Thai restaurant
- Cocktail bar
- Asian fusion restaurant

*How to change: GBP Dashboard → Edit profile → Business category → Add more categories*

---

## 3. GBP POST TEMPLATES (post once a week)

Post weekly to stay visible in Google's local feed. Use the photos from your Instagram.

---

### Post 1 — Tasting Menu (use food photo)

**Title:** The 9-Course Khaosan Tasting

**Body:**
```
Let the kitchen take the wheel.

Our Khaosan Tasting is 9 courses crafted by Chef Pond and Chef Toei — two MasterChef Thailand Season 3 finalists — starting from RM 158 per person.

Highlights this week: Somtum Tod with NZ mussel · Kuagling Taco with petai bean · Gai Yang with red curry and rambutan · Ma Muang coconut panna cotta to finish.

Add two cocktails for RM 88 more.

Reserve on WhatsApp — link in profile.
```

**Button:** Book → https://wa.me/60109182378

---

### Post 2 — Cocktails (use bar/drink photo)

**Title:** Cocktails built around Thai ingredients

**Body:**
```
No imported flavours, no generic menu.

Our bar programme is built around what Chef Toei and the team work with every night: kaffir lime leaf, Thai black tea, bah kut teh, Isaan sausage, lemongrass, pandan.

Try the BKT — whisky, bah kut teh clarified, shiitake. Or the Tom Kha Collins — gin, kaffir lime, tom kha. RM 50–55.

Open Tuesday to Sunday from 6pm. Walk-ins welcome at the bar.
56 Lebuh Campbell, George Town.
```

**Button:** Learn more → https://khaosanpg.com/#menu

---

### Post 3 — Date Night (use interior/ambiance photo)

**Title:** Best date night in George Town?

**Body:**
```
We hear it every weekend.

Six-seat bar, dim lighting, heritage shophouse on Campbell Street. Let Chef Pond and Chef Toei cook for you — small plates designed for sharing, cocktails worth lingering over.

Reserve ahead on WhatsApp or walk in for bar seats. Tuesday through Sunday, 6pm to midnight.

Tasting menus from RM 128 per person.
```

**Button:** Reserve → https://wa.me/60109182378

---

### Post 4 — Weekend Special (use chef/kitchen photo)

**Title:** This weekend at the kitchen

**Body:**
```
Chef Pond and Chef Toei are in the kitchen Tuesday through Sunday.

Start with Hoi Tod — crispy oysters, sriracha mayo. Move to Ceviche — sea prawns, halibut, green chilli, tobiko. Finish with Ma Prao — coconut gelato, salted duck egg yolk, crispy rice cracker.

Or just pull up a bar stool and ask what's new. The menu evolves. The kitchen always has something worth trying.

56 Lebuh Campbell, George Town. 6pm–12am.
```

**Button:** Get directions → https://maps.app.goo.gl/RsGntHvWTwZm8Vem7

---

## 4. GOOGLE Q&A — PRE-ANSWER THESE YOURSELF

Log into GBP and add these Q&As before customers ask. Google shows them prominently.

**Q: Do I need a reservation?**
A: Reservations are highly recommended, especially on weekends and for tasting menus. WhatsApp us at +60 10-918-2378 to book. Walk-ins are welcome at the bar.

**Q: Is there a dress code?**
A: Smart casual. The vibe is relaxed but the food is serious.

**Q: How much does it cost per person?**
A: À la carte dining typically runs RM 80–150 per person with drinks. Tasting menus start at RM 128 (7 courses) and RM 158 (9 courses) per person.

**Q: Is the food spicy?**
A: Some dishes are spicy — marked with 🌶 on the menu. Let the team know your heat preference and they'll advise.

**Q: Is there parking nearby?**
A: Yes — Campbell Street Car Park and 156 Jalan Penang Car Park are both within 200–300 metres.

**Q: Do you have halal options?**
A: Khaosan serves pork. The menu is not halal-certified.

**Q: Do you accept credit cards?**
A: Yes, we accept major credit and debit cards.

---

## 5. PHONE NUMBER — ACTION REQUIRED

**Two different numbers are showing across your platforms:**

| Platform | Number shown |
|---|---|
| Facebook | +60 10-918-2378 |
| The Yum List | +60 10-918-2378 |
| Website (lovable) | +60 10-918-2378 |
| GBP (check yours) | ??? |

**→ Pick ONE number and update every platform to match.**

Once confirmed, update:
- [ ] Google Business Profile
- [ ] Facebook page
- [ ] Instagram bio
- [ ] Website contact section
- [ ] Email The Yum List to correct their listing

---

## 6. PHOTO UPLOAD CHECKLIST FOR GBP

Google ranks businesses higher when the profile has 20+ photos with regular uploads. Upload these:

**Must-haves:**
- [ ] Exterior (daytime and night)
- [ ] Interior (bar area, dining room)
- [ ] Food: at least 10 different dishes
- [ ] Drinks: at least 5 cocktail photos
- [ ] Team/chefs in kitchen
- [ ] Tasting menu courses laid out
- [ ] Logo photo (high res)
- [ ] Cover photo (widescreen, best food shot)

**Tag each photo** with the appropriate category: Food, Interior, Exterior, Team.

---

## 7. REVIEW RESPONSE TEMPLATES

Use these to respond to every Google review. Responding improves your local ranking.

**For 5-star reviews:**
```
Thank you so much — this means a lot to the whole team, especially Chef Pond and Chef Toei who put everything into every plate. We'd love to have you back again soon. See you at the bar!
— Khaosan Tapas Bar
```

**For 4-star reviews:**
```
Thanks for the kind words! We'd love to know what would make it a 5-star experience next time — feel free to message us on Instagram @khaosanpg. Always room to do better. Hope to see you again soon!
— Khaosan Tapas Bar
```

**For critical reviews:**
```
Thank you for taking the time to share this. We're sorry your experience didn't match what we aim for — this is genuinely useful feedback for the team. Please reach out to us directly at khaosan.georgetown@gmail.com so we can make it right.
— Khaosan Tapas Bar
```

---

## 8. WEBSITE → MOVE TO khaosanpg.com

The SEO-optimized `khaosan-website.html` file in this folder is ready to deploy.

**To go live on khaosanpg.com:**

**Option A — Netlify (free, 5 minutes):**
1. Go to netlify.com → sign up free
2. Drag and drop `khaosan-website.html` onto their deploy page
3. Go to Site Settings → Domain → add custom domain → `khaosanpg.com`
4. Update your domain DNS to point to Netlify (they give you the settings)
5. Done — site is live and SSL-secured

**Option B — Cloudflare Pages (free):**
1. Go to pages.cloudflare.com
2. Upload the HTML file
3. Connect your domain (if registered via Cloudflare, it's automatic)

**After going live:**
- Update GBP website URL from lovable.app to khaosanpg.com
- Update Facebook page website URL
- Update Instagram bio link

---

*Generated June 2026 — update as menu and team change.*
